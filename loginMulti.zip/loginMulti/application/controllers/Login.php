<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Login_model');
	}

	public function index()
	{
		$this->load->view('Auth/login_v');
	}

	public function ceklogin()
	{
		if(isset($_POST['login'])) {
			$user = $this->input->post('user',true);
			$pass = md5($this->input->post('pass',true));
			$cek = $this->Login_model->prosesLogin($user,$pass);
			$hasil = count((array)$cek);
			if($hasil > 0) {
				$pelogin = $this->db->get_where('user', array('username' => $user, 
					'password' => $pass))->row();
				if($pelogin->level == 'admin'){
					redirect('Dashboard/index');
				} else if($pelogin->level == 'panitia') {
					redirect('Dashboard/panitia');
				} else if($pelogin->level == 'pemilih') {
					redirect('Dashboard/pemilih');
				}
			} else {
				redirect('Login/index');
			}
		}
	}

	public function Logout()
	{
		$this->session->session_destroy();
		redirect('Login/index');
	}
}

?>
