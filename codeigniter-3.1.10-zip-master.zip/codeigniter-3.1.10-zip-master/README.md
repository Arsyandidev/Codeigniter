[codeigniter-3.1.10-zip.bodyfitstation.com](http://codeigniter-3.1.10-zip.bodyfitstation.com)

## Testing
- [http://codeigniter-3.1.10-zip.bodyfitstation.com/index.php/welcome/assets_zip](http://codeigniter-3.1.10-zip.bodyfitstation.com/index.php/welcome/assets_zip)
